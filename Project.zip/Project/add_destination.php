<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
include('admintemplate.php');
echo "<style>input[type=text], select {
  width: 150%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solidred;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 50%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>";
        echo "<body id='content'><center><br><h3>Add Destination:</h3><form method='POST'><br><table>
<tr><td>Enter city:</td><td><input type='text' name='city' placeholder='City'></td></tr>
<tr><td>Description:</td><td><input type='text' name='description' placeholder='Description'></td></tr>
<tr><td>Hotplaces:</td><td><input type='text' name='hotplaces' placeholder='Seperate it with ,'></td></tr>
<tr><td></td><td><input type='submit' name='submit'></td></tr>
</table></form></center></html>";
 
if(isset($_POST['submit']))
{
$city=$_POST['city'];
$descr=$_POST['description'];
$hotplaces=$_POST['hotplaces'];
 
        if(preg_match("/^[a-zA-Z]+$/",$city))
        {
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $res=mysqli_query($con,"select count(*) from destination where city='$city'");
        $result=mysqli_fetch_row($res);
        if($result[0]==0)
        {
                if(preg_match("/^[a-zA-Z]+(\s[A-Za-z]+)*$/",$descr))
                {
                        if(preg_match("/^([a-zA-Z]+(\s[A-Za-z]+)*)+(,([a-zA-Z]+(\s[A-Za-z]+)*)+)*$/",$hotplaces))
                        {
                                //echo $city;
                                //echo $descr;
                                //echo $hotplaces;
                                mysqli_query($con,"insert into destination values('$city','$descr','$hotplaces','0')");
                                echo "<center><h2>Data Inserted!!</h2></center>";
                        }
                        else{echo "<script>alert('Invalid Hot Places!!!')</script>";}
                }else{echo "<script>alert('Invalid Description!!!')</script>";}
        }else{echo "<script>alert('City Already Exists!!!')</script>";}
        }else{echo "<script>alert('Invalid City!!!')</script>";}
}
echo "</body>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
 
 
 
?>
