<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
include('admintemplate.php');
echo "<style>input[type=text], select,input[type=number] {
  width: 150%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solidred;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 100%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>";
echo "<head><title>add_remove</title></head>
<body id='content'>
 
        <br><center><h3>Add/Remove Hotels!!!</h3></center><br>
        <form name='add_remove' method='POST'><center>
        <table>
        <tr><td><input type='submit' name='add' value='ADD!'></td>
        <td><input type='submit' name='remove' value='REMOVE!'></td></tr>
        </table></center></form>";
if(isset($_POST['add']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        echo "<center><form name='adding' method='POST'>
        <table>
        <tr><td><b>Select Destination:</b></td><td><select name='dest' required>
        <option value=''>--SELECT--</option>";
        $res=mysqli_query($con,"select city from destination");
        while($result=mysqli_fetch_row($res))
        {
                echo "<option value='$result[0]'>$result[0]</option>";
        }
        echo "</select></td></tr></table>
        <center><input type='submit' name='btn1' value='Show!' style='width:10%'></center></center></form>";
}
if(isset($_POST['btn1']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $city1=$_POST['dest'];
        //session_start();
        $_SESSION['destin']=$city1;
        $r1=mysqli_query($con,"select count(*) from hotels where city='$city1'");
        $re1=mysqli_fetch_row($r1);
        if($re1[0]<10)
        {
        echo "<center><form method='post'><table><tr><td>Hotel Name:</td><td><input type='text' name='hname' placeholder='Hotel Name'></td></tr>
        <tr><td>Address:</td><td><input type='text' name='address' placeholder='Address'></td></tr>
        <tr><td>No. of Rooms:</td><td><input type='number' name='rooms' min='2' max='10' placeholder='No. of Rooms'></td></tr>
        <tr><td>Price:</td><td><input type='text' name='pri' placeholder='Price'></td></tr>
        </table>
        <center><input type='submit' name='btn2' value='Ok!' style='width:10%'></center>
        </form></center>
        ";
        }
       else
        {
                echo "<center><h3>There are already 10 hotels present For the city $city!!</h3></center>";
        }
}
if(isset($_POST['btn2']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $hname1=$_POST['hname'];
        $address1=$_POST['address'];
        $nroom=$_POST['rooms'];
        $price1=$_POST['pri'];
        //session_start();
        $destined=$_SESSION['destin'];
        $a1=mysqli_query($con,"select count(*) from hotels where name='$hname1' and city='$destined'");
        $a2=mysqli_fetch_row($a1);
        if(preg_match("/^[A-Za-z]+(\s[A-Za-z]+)*$/",$hname1))
        {
                if($a2[0]==0)
                {
                        if(preg_match("/^[A-Za-z]+([\s]?[,]?[\s]?[A-Za-z]+)*$/",$address1))
                        {
                                if($price1>500)
                                {
                                        mysqli_query($con,"insert into hotels values('$hname1','$address1','0','$destined','$nroom','0','$price1')");
                                        echo "<center><h3>Successfully Added!!!</h3></center>";
                                        header("refresh:1");
                                }else{echo "<script>alert('Invalid price')</script>";}
                        }else{echo "<script>alert('Invalid address')</script>";}
                }else{echo "<script>alert('Hotel already exists!!')</script>";}
        }else{echo "<script>alert('Invalid Hotel Name')</script>";}
}
if(isset($_POST['remove']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        echo "<center><form name='removing' method='POST'>
        <table>
        <tr><td><b>Select Destination:</b></td><td>
        <select name='des' required>
                <option value=''>Select the Destination</option>";
                $res1=mysqli_query($con,"select city from destination");
                while($result1=mysqli_fetch_row($res1))
                {
                        echo "<option value='$result1[0]'>$result1[0]</option>";
                }
        echo "</select></td></tr></table>
        <center><input type='submit' name='button1' value='Show!' style='width:10%'></center></form>";
}
if(isset($_POST['button1']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $city=$_POST['des'];
        $r=mysqli_query($con,"select count(*) from hotels where city='$city'");
        $re=mysqli_fetch_row($r);
        if($re[0]>0)
        {
        echo "<form method='post'><table><td><tr>
        <center><b>Select a Hotel:</b><select name='hotel' style='width:20%'equired>
        <option value=''>Select the Hotel</option>";
        $res3=mysqli_query($con,"select name from hotels where city='$city'");
        while($result3=mysqli_fetch_row($res3))
        {
                echo "<option value='$result3[0]'>$result3[0]</option>";
        }
        echo "</select></center>
        </td>
        </tr>
        </table>
        <center><input type='submit' name='button2' value='Ok!' style='width:10%'></center>
        </form>
        ";
        }
        else
        {
                echo "<center><h3>No hotels Exist For the city $city!!</h3></center>";
        }
}
if(isset($_POST['button2']))
{
        $hotel1=$_POST['hotel'];
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        mysqli_query($con,"delete from hotels where name='$hotel1'");
        echo "<center><h3>Deleted Successfully!!</h3></center>";
        header("refresh:2");
}
 
//echo "</div></div></html>";
 
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
?>
