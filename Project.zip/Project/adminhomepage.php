<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
include('admintemplate.php');
echo "<body id='content'>";
$email1=$_SESSION['aemail'];
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$res=mysqli_query($con,"select username from user where email='$email1'");
$result=mysqli_fetch_row($res);
$res1=mysqli_query($con,"select adminname from admin where email='$email1'");
$result1=mysqli_fetch_row($res1);
#$_SESSION['usern']=$email1;
echo "<center><p><h2><b>HELLO $result[0]$result1[0]!!<br>Welcome to Trip Tip<br><b></h2></p></center>";
echo "</body>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
