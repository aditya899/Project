<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
  tr:hover {background-color:#e6f5ff;}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
echo "<body id='content'><center><br><h3>Want to Cancel?</h3><br>";
date_default_timezone_set("Asia/Calcutta");
$today=date('d-m-Y');
#session_start();
$flag=0;
$user1=$_SESSION['cemail'];
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$res1=mysqli_query($con,"select count(*) from bookings where useremail='$user1'");
$result1=mysqli_fetch_row($res1);
if($result1[0]>0)
{
$res=mysqli_query($con,"select * from bookings where useremail='$user1'");
echo "<center><form method='post'><table border=1px  bgcolor=#b3e0ff><tr><th>Booking Id</th><th>City</th><th>Hotel</th><th>Check In</th><th>Check Out</th><th>Cancel</th></tr>";
while($result=mysqli_fetch_row($res))
{
        echo "<tr><td>$result[0]</td><td>$result[4]</td><td>$result[5]</td>";
        echo "<td>$result[1]</td><td>$result[2]</td>";
        $var1=strtotime($result[1]);
        $var2=strtotime($today);
        if($var2>=$var1)
        {
                echo "<td>NA</td></tr>";
        }
        else
        {
                echo "<td><input type='radio' name='choice' value='$result[0]'></td></tr>";
                $flag=$flag+1;
        }
}
echo "</table>";
if($flag>0)
{
        echo "<br><center><input type='submit' name='cancel' value='Cancel'></center></form></center>";
}
else
{
        echo "</form></center>";
}
if(isset($_POST['cancel']))
{
        //$_SESSION['choice1']=$_POST['choice'];
        if(empty($_POST['choice']))
        {
                echo "<script>alert('Select the booking you want to Cancel')</script>";
        }
        else
        {
                $_SESSION['choice1']=$_POST['choice'];
                $ch=$_POST['choice'];
                echo "<center><b>Your Booking for booking id $ch will be cancelled!!";
                echo "<br>Are you sure?<br><form method='post'></b><input type='submit'name='yes' value='Yes!'></form></center>";
        }
}
if(isset($_POST['yes']))
{
        $ch=$_SESSION['choice1'];
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $res2=mysqli_query($con,"select no_of_rooms,city,hotel_name from bookings where bid='$ch'");
        $result2=mysqli_fetch_row($res2);
        mysqli_query($con,"update hotels set rooms_booked=rooms_booked-'$result2[0]' where name='$result2[2]' and city='$result2[1]'");
        $res3=mysqli_query($con,"delete from bookings where bid='$ch'");
        echo "<h3><center>Your Booking has been Cancelled!!</center></h3>";
        header("refresh:2");
}
}
else
{
        echo "<center><h1>You dont have any bookings</h1>";
        echo "<h3>Redirecting you to the home!</h3></center>";
        header("refresh:1,url=customerhomepage.php");
 
}
 
 
 
echo "</body></center></html>";
 
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
