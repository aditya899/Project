<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
#content
{
        background-image:url('bokeh.jpg');
        background-position:center;background-repeat:no-repeat;background-size:cover;
}
input[type=text], select,input[type=password] {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit],input[type=reset] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
 
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail'])  || isset($_SESSION['cemail']))
{
$con=mysqli_connect("localhost","T1014659","#infy123","test_T1014669");
echo "
        <head>
                <title>Change password Page</title>
        </head>
        <body id='content'>
        <center><br><br><br>
        <div>
                <h1>Change Password:</h1>
                <form name='login' method='POST'>
                        <table><b>
                        <tr><td><b>Old Password:</b></td><td><input type='password' name='opass'></td></tr>
 
 
                        <tr><td><b>New Password:</b></td><td><input type='password' name='npass'></td></tr>
                        <tr><td><b>Confirm Password:</b></td><td><input type='password' name='npass2'></td></tr></table>
                        <input type='submit' name='submit' value='Confirm'>
                        <input type='reset' value='Reset'></td></tr>
                        <input type='submit' name='cancel' value='Cancel'>
 
                </form>
        </div>
        </center>
        </body>";
if(isset($_POST['submit']))
        {
                $opass=$_POST['opass'];
                $npass=$_POST['npass'];
                $conpass=$_POST['npass2'];
                //$email=$_POST['email'];
                if(isset($_SESSION['aemail'])){$aemail=$_SESSION['aemail'];}
                if(isset($_SESSION['cemail'])){$cemail=$_SESSION['cemail'];}
 
                                if(empty($opass)||empty($npass)||empty($conpass))
                                {
                                        echo '<script>alert("Enter all the fields first")</script>';
                                }
                                else
                                {
                                 if(isset($_SESSION['aemail'])){$chad=mysqli_query($con,"select count(*) from admin where email='$aemail'");
                                        $chad1=mysqli_fetch_row($chad); $chu1[0]=0;}
 
                                if(isset($_SESSION['cemail'])){$chu=mysqli_query($con,"select count(*) from user where email='$cemail'");
                                        $chu1=mysqli_fetch_row($chu); $chad1[0]=0;}
 
                               if(isset($_SESSION['aemail'])){$res=mysqli_query($con,"select password from admin where email='$aemail'");
                                        $result=mysqli_fetch_row($res); $result1[0]=0;}
                                if(isset($_SESSION['cemail'])){ $res1=mysqli_query($con,"select password from user where email='$cemail'");
                                        $result1=mysqli_fetch_row($res1); $result[0]=0;}
                                        if($chad1[0]==0 && $chu1[0]==0)
                                        {
                                                echo "<script>alert('Email is not registered')</script>";
                                        }
                                        else
                                        {
                                        if(($result[0]!=$opass) || ($result1[0]!=$opass))
                                        {
                                        echo "<script>alert('Old password does not match')</script>";
                                        }
                                        elseif($npass==$opass)
                                        {
                                        echo "<script>alert('Old and new passwords can not be same')</script>";
                                        }
                                        else
                                        {
                                        if(preg_match("/^[A-Za-z0-9!$*-]+$/",$npass))
                                        {
                                                if(preg_match("/[A-Z]/",$npass))
                                                {
                                                        if(preg_match("/[a-z]/",$npass))
                                                        {
                                                                if(preg_match("/[!*$-]/",$npass))
                                                                {
                                                                        if($npass==$conpass)
                                                                        {
                                                                                if($chad1[0]==1 && $chu1[0]==0)
                                                                                {
                                                                                $n1=mysqli_query($con,"select adminname from admin where email='$aemail'");
                                                                                $n2=mysqli_fetch_row($n1);
                                                                                mysqli_query($con,"Update admin set password='$conpass' where email='$aemail'");
                                                                                echo "<script>alert('$n2[0],your password is updated successfully!')</script>";
                                                                                }
                                                                                else
                                                                                {
                                                                                $n3=mysqli_query($con,"select username from user where email='$cemail'");
                                                                                $n4=mysqli_fetch_row($n3);
                                                                                mysqli_query($con,"Update user set password='$conpass' where email='$cemail'");
                                                                                echo "<script>alert('$n4[0],your password  is updated successfully!')</script>";
                                                                                }
                                                                        }
                                                                        else{echo '<script>alert("Passwords do not match")</script>'; return false;}
                                                                }
                                                                else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                                        }
                                                        else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                                }
                                                else{echo '<script>alert("Password should contain atleast 1 uppercase, 1lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                        }
                                        else{echo '<script>alert("Invalid Password")</script>'; return false;}
 
 
                                        }
                                        }
        }
      }
 
elseif(isset($_POST['cancel']))
{
         if(isset($_SESSION['aemail'])){$aemail=$_SESSION['aemail'];}
         if(isset($_SESSION['cemail'])){$cemail=$_SESSION['cemail'];}
if(isset($_SESSION['cemail'])){$us=mysqli_query($con,"select count(*) from user where email='$cemail'");
        $us1=mysqli_fetch_row($us); $ad1[0]=0;}
if(isset($_SESSION['aemail'])){$ad=mysqli_query($con,"select count(*) from admin where email='$aemail'");
        $ad1=mysqli_fetch_row($ad); $us1[0]=0;}
        if($ad1[0]==1)
        {
                header("location:adminhomepage.php");
        }
        elseif($us1[0]==1)
        {
                header("location:customerhomepage.php");
        }
}
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
