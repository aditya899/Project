<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
 
<?php
session_start();
if(isset($_SESSION['aemail']))
{
include('admintemplate.php');
echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solidred;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>";
echo "<body id='content'>";
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$result=mysqli_query($con,"select email  from user where status='active'");
echo "<html><form method='POST'><br><center><h3>Delete User:</h3><br>
        <b>Select User to Delete:</b><select  name='user'>
        <option value=-1>--SELECT--</option>";
                while ($row=mysqli_fetch_row($result))
                {
                        echo "<option value='$row[0]'>$row[0]</option>";
                }
        echo "<input type='submit' name='submit' value='Submit'>
         </select></center></form>
</html>";
 
if(isset($_POST['user']))
{
        $user=$_POST['user'];
        if($user!=-1)
        {
                $result1=mysqli_query($con,"update  user set status='inactive' where email='$user'");
                echo "<script>alert('$user is inactive now!!')</script>";
                header('refresh:3');
        }
        else
        {
                echo "<script>alert('Select User to Delete!!')</script>";
        }
}
echo "</body>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
 
 
 
 
?>
