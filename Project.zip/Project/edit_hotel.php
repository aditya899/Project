<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
        include('admintemplate.php');
        echo "<body id='content'>";
        echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
 
        echo "<center><br><h3>Edit Hotels:</h3><br>";
?>
 
 
 
 
<?php
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$res_city=mysqli_query($con,"select city from destination");
echo "
        <html>
        <head></head>
        <body>
        <form method='POST'>
        <b>Select Destination:</b><select name='dest'><option value=''>--Select Destination--</option>'";
        while($row=mysqli_fetch_row($res_city))
        {
                echo"<option value=".$row[0].">".$row[0]."</option>";
        }
echo "
        </select>
        <input type='submit' name='submit1' value='Select'>
        </form>
        </body>
        </html>";
 
if(isset($_POST['submit1']))
{
$destination=$_POST['dest'];
//session_start();
$_SESSION['dest']=$destination;
         if($_POST['dest']=="")
        {
                echo "<script>alert('Select a Destination')</script>";
        }
        else
        {
                $a1=mysqli_query($con,"select count(*) from hotels where city='$destination'");
                $a2=mysqli_fetch_row($a1);
                if($a2[0]>0)
                {
               $res_hotel=mysqli_query($con,"select name from hotels where city='$destination'");
                echo "<html>
                <body>
                <form method='POST'>
                Select Hotel:<select name='hot'><option value=''>---Select Hotel---</option>";
                 while($hrow=mysqli_fetch_row($res_hotel))
                {
                        echo"<option>".$hrow[0]."</option>";
                }
echo "</select>
                <input type='submit' name='submit2' value='Edit'>
                </form>
                </body>
                </html>";
                }
                else
                {
                        echo "<h4>No Hotels available for $destination!!</h4>";
                }
        }
 
}
 
 
?>
<?php
                if(isset($_POST['submit2']))
                {
                //session_start();
                $destin1=$_SESSION['dest'];
                $f=$_POST['hot'];
                //echo "<script>alert('$f')</script>";
                        if($_POST['hot']=="")
                        {
                        echo "<script>alert('Select a Hotel')</script>";
                        }
                        else
                        {
                        $_SESSION['city1']=$destin1;
                        echo $_POST['hot'];
                        $_SESSION['hotel1']=$_POST['hot'];
                        /*setcookie('city',$destin1,time()+3600);
                        setcookie('hotel',$_POST['hot'],time()+3600);*/
                        header('location:hotelvalue.php');
                        }
                 }
echo "</center></body>";
}
 
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
