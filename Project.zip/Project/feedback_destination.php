<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
 
echo "<style>input[type=text], select,textarea,input[type=number] {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
echo "<body id='content'><center><br>";
#session_start();
$email=$_SESSION['cemail'];
 
$con=mysqli_connect("localhost","T1014659","#infy123","test_T1014669");
$city=mysqli_query($con,"select distinct city from bookings where useremail='$email'");
 
 
$count=mysqli_query($con,"select count(*) from bookings where useremail='$email'");
$count1=mysqli_fetch_row($count);
if($count1[0]==0)
{
        echo "<center><h1>'You have not chosen your destination yet!</h1></center>";
        header("refresh:2,url=customerhomepage.php");
}
else
{
echo "<h3>Rate Your Visit:</h3><br>";
echo "<form method=post><center><table>
<tr><td>City:</td><td><select name='a'>";
echo "<option value=''>--Select--</option>";
while($row=mysqli_fetch_row($city))
{
echo "
<option>".$row[0]."</option>";
}
echo "
</select></td></tr>
<tr><td>Rating:</td><td><input type=number min=0 max=5 name=rate>
</td></tr>
<tr><td>Review:</td><td><textarea name='review' value='re'></textarea></td></tr>
</table><input type='submit' value='Submit' name='button1'></form>";
 
if(isset($_POST['button1']))
{
        $city=$_POST['a'];
        $review=$_POST['review'];
        $rating=$_POST['rate'];
        if(empty($city) || empty($rating) || empty($review))
        {
        echo "<script>alert('Fill all the fields')</script>";
        }
 
 
        elseif($city=='')
        {
        echo "<script>alert('Destination is invalid')</script>";
        }
 
        else
        {
                if(preg_match("/^[a-zA-Z]+(\s[A-Za-z]+)*$/",$review) && strlen($review)<=50)
                {
                        mysqli_query($con,"insert into review_city values('$city','$rating','$review')");
 
                        $a=mysqli_query($con,"select rating from review_city where city='$city'");
                        $b=mysqli_query($con,"select count(*) from review_city where city='$city'");
                        $co=mysqli_fetch_row($b);
                        $sum=0;
                        while($d=mysqli_fetch_row($a))
                        {
                                $sum=$sum+$d[0];
                        }
                        $avg=$sum/$co[0];
 
                        mysqli_query($con,"update destination set avg_rating='$avg' where city='$city'");
                        echo "<script>alert('Review has been submitted!')</script>";
                }
                else
                {
                echo "<script>alert('Invalid review!')</script>";
                }
        }
 
 
}
 
}
echo "</html>";
 
echo "</center>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
