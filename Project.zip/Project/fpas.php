<?php
session_start();
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
echo "<style>input[type=text], select,input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
#content
{
        color:white;
        background-image:url('cyber-security.jpg');
background-size:cover;
        background-position:center;
}</style>";
echo "<body id='content'>";
echo "<head><title>Forgot password page</title></head>";
echo "<center>
        <div>
                <h1>Forgot Password:</h1>
                <form name='login' method='POST'>
                         <table>
                        <tr><td><b>Registered Email-ID:</b></td><td><input type='text' name='email'></td></tr></table>
                        <input type='submit' name='button1' value='Check'>&ensp;<input type='submit' name='a' value='Cancel'></form>";
if(isset($_POST['a']))
{
header("Location:login.php");
}
 
if(isset($_POST['button1']))
{
        $_SESSION['email']=$_POST['email'];
        $usere=$_POST['email'];
        $one=mysqli_query($con,"Select count(*) from user where email='$usere'");
        $adm=mysqli_query($con,"Select count(*) from admin where email='$usere'");
        $a=mysqli_fetch_row($one);
        $b=mysqli_fetch_row($adm);
        $_SESSION['usere']=$usere;
        if(empty($usere))
        {
                echo "<script>alert('Email can not be empty!')</script>";
        }
        else
        {
        if(preg_match("/^[A-Za-z]+([._][A-Za-z0-9]+)*[0-9]*[@][a-zA-Z]+[.][a-zA-z]{3,5}$/",$usere))
        {
                if($a[0]==1)
                {
                        $one1=mysqli_query($con,"Select security_ques from user where email='$usere'");
                        $result=mysqli_fetch_row($one1);
                        echo "<form name='new' method='POST'><table><tr><td>Security Question:</td><td>$result[0]</td></tr>";
                        echo "<tr><td>Your Answer:</td><td><input type='text' name='ans'></td></tr>";
                        echo "</table><center><input type='submit' name='button2' value='Check'></center></form>";
                }
 
                elseif($b[0]==1)
                {
                        $one2=mysqli_query($con,"Select security_ques from admin where email='$usere'");
                        $result1=mysqli_fetch_row($one2);
                        echo "<form name='new' method='POST'><table><tr><td>Security Question:</td><td>$result1[0]</td></tr>";
                        echo "<tr><td>Your Answer:</td><td><input type='text' name='ans'></td></tr>";
                        echo "</table><center><input type='submit' name='button2' value='Check'></center></form>";
                }
                else
                {
                        echo "<script> alert('Not registered email!!')</script>";
                }
        }
        else
        {
                echo "<script>alert('Invalid email')</script>";
        }
        }
        echo "</table></form></div></center>";
        $_SESSION['admincount']=$b[0];
        $_SESSION['usercount']=$a[0];
}
if(isset($_POST['button2']))
        {
                $usere=$_SESSION['usere'];
                $answer=$_POST['ans'];
                if(empty($answer))
                                {
                                        echo '<script>alert("Enter your answer")</script>';
                                }
                                else
                                {
                                        $res=mysqli_query($con,"select security_ans from user where email='$usere'");
                                        $res1=mysqli_query($con,"select security_ans from admin where email='$usere'");
                                        $result=mysqli_fetch_row($res);
                                        $result1=mysqli_fetch_row($res1);
                                #       echo "<script>alert($result)</script>";
                                        if($result[0]==$answer || $result1[0]==$answer)
                                        {
                                                echo "<form name='new1' method='POST'><center><table><tr><td><b>Enter new password:</b></td>
                                                <td><input type='password' name='pwd' placeholder='New Password'></td></tr>
                                                <tr><td><b>Confirm password:</b></td>
                                                <td><input type='password' name='confirm' placeholder='Confirm Password'></td></tr>";
                                                echo "</table><center><input type='submit' name='submit' value='OK!'></center></center></form>";
                                        }
                                        else
                                        {
                                        echo "<script>alert('Answer is not correct!')</script>";
                                        }
                                }
        }
        if(isset($_POST['submit']))
        {
                $usere=$_SESSION['usere'];
                $password=$_POST['pwd'];
                $confirm=$_POST['confirm'];
                $admincount=$_SESSION['admincount'];
                $usercount=$_SESSION['usercount'];
 
 
                if(preg_match("/^[A-Za-z0-9!$*-]+$/",$password))
                {
                        if(preg_match("/[A-Z]/",$password))
                        {
                                if(preg_match("/[a-z]/",$password))
                                {
                                        if(preg_match("/[!*$-]/",$password))
                                        {
                                                if($password==$confirm)
                                                {
                                                        if($usercount==1)
                                                        {
                                                        mysqli_query($con,"Update user set password='$password' where email='$usere'");
                                                        echo "<b><script>alert('Password updated successfully')</script>";
                                                        echo "<center>Do you Want to go to login page?</center>";
                                                        echo "<form action='login.php'><input type='submit' name='button4' value='Ok'></form>";
                                                        }
                                                        elseif($admincount==1)
                                                        {
                                                        mysqli_query($con,"Update admin set password='$password' where email='$usere'");
                                                        echo "<script>alert('Password updated successfully')</script>";
                                                        echo "<center>Do you Want to go to login page?</center>";
                                                        echo "<form action='login.php'><input type='submit' name='button4' value='Ok'></form></b>";
                                                        }
 
                                                }
                                                else{echo '<script>alert("Passwords do not match")</script>'; return false;}
                                        }
                                        else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                }else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                        }else{echo '<script>alert("Password should contain atleast 1 uppercase, 1lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                 }else{echo '<script>alert("Invalid Password")</script>'; return false;}
        }
?>
