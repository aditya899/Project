<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']) || isset($_SESSION['aemail']))
{
include('admintemplate.php');
echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
 
tr:hover {background-color:#e6f5ff;}</style>";
echo "<body id='content'><center><br><h3>Generate Report</h3>";
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
echo "<form method='POST'><br>
        <b>Select an Option :</b><select  name='opt' >
        <option value=''>--SELECT--</option>
        <option value='user'>User</option>
        <option value='city'>City</option>
        </select>
        <input type='submit' name='generate' value='Choose'></form>";
 
if(isset($_POST['generate']))
{
$opt=$_POST['opt'];
        if(empty($opt))
        {
                echo "<script>alert('Select an Option!!')</script>";
        }
        else
        {
                echo "<form method='POST'><table>";
                if($opt=='user')
                {
                $res=mysqli_query($con,"Select * from user");
        echo "<table border=2 bgcolor=#b3e0ff><tr><th>Username</th><th>Email</th><th>Gender</th><th>DOB</th><th>Phone number</th><th>Status</th></tr>";
                while($result=mysqli_fetch_row($res))
                {
                        echo "<tr><td>$result[0]</td><td>$result[1]</td><td>$result[2]</td><td>$result[3]</td><td>$result[5]</td><td>$result[8]</td></tr>";
                }
                echo "</table>";
                }
                else if($opt=='city')
                {
                $res=mysqli_query($con,"Select d.city,d.description,d.hot_places,h.name,h.total_rooms,h.rooms_booked from destination d right join hotels h on d.city=h.city order by d.city ");
 
                echo "<table border=2 bgcolor=#b3e0ff><tr><th>City</th><th>Description</th><th>Hot places</th><th>Hotel Name</th><th>Total rooms</th><th>Rooms Booked</th><th>Available rooms</th></tr>";
 
                while($result=mysqli_fetch_row($res))
                {
                        $avail_rooms=$result[4]-$result[5];
                        echo "<tr><td>$result[0]</td><td>$result[1]</td><td>$result[2]</td><td>$result[3]</td><td>$result[4]</td><td>$result[5]</td><td>$avail_rooms</td></tr>";
                }
                echo "</table>";
                }
        }
}
echo "</center>";
 
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
