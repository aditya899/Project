<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
 
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
echo "<style>input[type=text], select,input[type=number] {
  width: 70%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 20%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
echo "<body id='content'><center><br><h3>Book Your Hotel:</h3><br>";
date_default_timezone_set("Asia/Calcutta");
#session_start();
$city1=$_SESSION['city'];
$hname=$_SESSION['hotel'];
$email=$_SESSION['cemail'];
echo "<form  method='post'><table><tr><th>$city1</th><th>$hname</th></tr><tr><td></td></tr><tr><td></td></tr>";
echo "<tr><td>Check In:</td><td><input type='text' name='cin' placeholder='dd-mm-yyyy'></td></tr>
        <tr><td>Check Out:</td><td><input type='text' name='cout' placeholder='dd-mm-yyyy'></td></tr>";
echo "<tr><td>No. of Rooms:</td><td><input type='number' name='nor' min='1' max='10'></td></tr></table>
        <input type='submit' name='btn1' value='Check availability!'></form>";
 
if(isset($_POST['btn1']))
{
        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $cin1=$_POST['cin'];
        $cout1=$_POST['cout'];
        $ci=date('d-m-Y',strtotime($cin1));
        $co=date('d-m-Y',strtotime($cout1));
        $diff3=date_create($ci);
        $diff2=date_create($co);
        $diff1=date_diff($diff2,$diff3);
        $diff1=$diff1->d+1;
 
        //$diff1=date_diff(date('d-m-Y',strtotime($cin1)),date('d-m-Y',strtotime($cout1)));
        $nor1=$_POST['nor'];
        $a=array();
        $b=array();
        $a=explode('-',$cin1);
        $b=explode('-',$cout1);
        $today=date('d-m-Y');
        if(preg_match("/^[0-9]{2}-[0-9]{2}-[0-9]{4}$/",$cin1))
        {
                if(preg_match("/^[0-9]{2}-[0-9]{2}-[0-9]{4}$/",$cout1))
                {
                        if(checkdate($a[1],$a[0],$a[2]) && checkdate($b[1],$b[0],$b[2]))
                        {
                                if(strtotime($today)<strtotime($ci) && strtotime($today)<strtotime($co) && strtotime($ci)<strtotime($co))
                                {
                                        $res1=mysqli_query($con,"select total_rooms,rooms_booked from hotels where city='$city1' and name='$hname'");
                                        $result1=mysqli_fetch_row($res1);
                                        $diff=$result1[0]-$result1[1];
                                        if($diff>=$nor1)
                                        {
                                                //mysqli_query($con,"update hotels set rooms_booked=rooms_booked+'$nor1' where city='$city1' and name='$hname'");
                                                $res2=mysqli_query($con,"select count(*) from bookings");
                                                $result2=mysqli_fetch_row($res2);
                                                if($result2[0]>0)
                                                {
                                                        $d=array();
                                                        $strn='';
                                                        $res3=mysqli_query($con,"select bid from bookings");
                                                        while($result3=mysqli_fetch_row($res3))
                                                        {
                                                                $strn=substr($result3[0],1);
                                                                array_push($d,$strn);
                                                        }
                                                        $maxm=max($d);
                                                        $bid=$maxm+1;
                                                        $bid1='B'.$bid;
                                                        echo "<b>Your Booking Id will be:$bid1</b>";
                                                }
                                                else
                                                {
                                                        $bid1='B1001';
                                                }
                                                $res4=mysqli_query($con,"select price from hotels where city='$city1' and name='$hname'");
                                                $result4=mysqli_fetch_row($res4);
                                                $price1=$result4[0]*$nor1*$diff1;
                                                echo "<b><center>Your Total room cost will be $price1 for $diff1 days!!!";
                                                echo "<form method='post'>Do you want to Book It!!!?</b><br><input type='submit' name='confirm' value='Confirm Booking'></form></center>";
                                                $_SESSION['bid1']=$bid1;
                                                $_SESSION['cin1']=$cin1;
                                                $_SESSION['cout1']=$cout1;
                                                $_SESSION['nor1']=$nor1;
                                                $_SESSION['price1']=$price1;
                                                //mysqli_query($con,"Insert into bookings values('$bid1','$cin1','$cout1','$nor1','$city1','$hname','$price1')")
                                        }else{echo "<script>alert('Selected no. of rooms no available!!')</script>";}
                                }else{echo "<script>alert('Dates are Incorrect')</script>";}
                        }else{echo "<script>alert('Dates are Incorrect')</script>";}
                }else{echo "<script>alert('Invalid Format')</script>";}
        }else{echo "<script>alert('Invalid Format')</script>";}
}
if(isset($_POST['confirm']))
{
         $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
        $bid1=$_SESSION['bid1'];
        $cin1=$_SESSION['cin1'];
        $cout1=$_SESSION['cout1'];
        $nor1=$_SESSION['nor1'];
        $price1=$_SESSION['price1'];
        mysqli_query($con,"Insert into bookings values('$bid1','$cin1','$cout1','$nor1','$city1','$hname','$price1','$email')");
        mysqli_query($con,"update hotels set rooms_booked=rooms_booked+'$nor1' where city='$city1' and name='$hname'");
        echo "<b>Your Booking has been Confirmed!!!</b>";
        header("refresh:5;url=customerhomepage.php");
}
echo "</center></body>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
