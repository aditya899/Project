<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
include('admintemplate.php');
 
echo "<style>input[type=text], select, input[type=number] {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
//session_start();
$des_city=$_SESSION['city1'];
$des_hotel=$_SESSION['hotel1'];
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$res1=mysqli_query($con,"select total_rooms, price from hotels where city='$des_city' and name='$des_hotel'");
$rp=mysqli_fetch_row($res1);
echo"<html>
     <body id='content'>
     <form method='POST'><center><br><h3>Edit Hotels:</h3><br>
     <table>
     <tr><td>City:</td><td><input type='text' name='city' value='$des_city' disabled></td></tr>
     <tr><td>Hotel Name:</td><td><input type='text' name='hname' value='$des_hotel'></td></tr>
     <tr><td>Select No. of  Rooms:</td><td><input type='number' name='nroom' min='2' max='10' value='$rp[0]'></td></tr>
     <tr><td>Room Price:</td><td><input type='text' name='price' value='$rp[1]'></td></tr>
     </table>
     <input type='submit' name='submit3' value='Update'/>
     <input type='submit' name='submit4' value='Reset'/>
    </center> </form>";
if(isset($_POST['submit4']))
{
        header('Location:edit_hotels.php');
}
if(isset($_POST['submit3']))
{
$ncity=$des_city;
$nhotel=$_POST['hname'];
$newroom=$_POST['nroom'];
$nprice=$_POST['price'];
        if(empty($ncity)|| empty($nhotel)|| empty($newroom)|| empty($nprice))
        {
                echo"<script>alert('Enter all the values')</script>";
        }
        else
        {
                if(preg_match("/^[a-zA-Z]+(\s[A-Za-z]+)*$/",$ncity))
                {
                        if(preg_match("/^[a-zA-Z]+(\s[A-Za-z]+)*$/",$nhotel))
{
                        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
                        mysqli_query($con,"update hotels set city='$ncity',name='$nhotel',total_rooms='$newroom',price='$nprice' where city='$des_city' and name='$des_hotel'");
                         echo"<script>alert('Updated successfully')</script>";
                        header('refresh:1,url=adminhomepage.php');
                        }else { echo"<script>alert('Hotel name is invalid')</script>";}
                }else { echo"<script>alert('City is invalid')</script>";}
       }
}
 
 
 
echo "</body></html>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
 
?>
