<html>
        <head><title>Sign Up</title>
        <style>
input[type=submit],input[type=reset] {
  width: 12%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
input[type=text], select {
  width: 150%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid red;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
    width: 150%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border-radius: 4px;
    box-sizing: border-box;
  }
.bg
{
color:white;
background-image:url('pexels-photo-1229861.jpeg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
 
</style>
 
        </head>
        <body class='bg'>
        <center>
        <div>
        <h1>Welcome to TripTip!</h1><h3>User Sign Up:</h3>
        <form method="POST">
                <table>
                <tr><td>User Name:</td><td><input type="text" name="username"></td></tr>
                <tr><td>Email-Id:</td><td><input type="text" name="email"></td></tr>
                <tr><td>Gender:</td><td><input type="radio" name="gender" value="Male" checked>Male
                <input type="radio" name="gender" value="Female">Female
                <input type="radio" name="gender" value="Others">Others</td></tr>
                <tr><td>Date of Birth:</td><td><input type="text" name="dob"></td></tr>
                <tr><td>Password:</td><td><input type="password" name="password"></td></tr>
                <tr><td>Confirm Password:</td><td><input type="password" name="confirm"></td></tr>
                <tr><td>Contact:</td><td><input type="text" name="contact"></td></tr>
                <tr><td>Security Question:</td><td><select name="security">
                <option value="">--SELECT--</option>
                <?php
                        $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
                        $res1=mysqli_query($con,"select * from security_question");
                        while($result1=mysqli_fetch_row($res1))
                        {
                                echo "<option value='$result1[0]'>$result1[0]</option>";
                        }
                ?>
                </select>
                </td></tr>
                <tr><td>Security Answer:</td><td><input type="text" name="ans"></td></tr>
                </table>
<br><br>
<input type="submit" name="submit" value="Register">
<input type="reset" value="Reset">
<input type="submit" name="cancel" value="Cancel">
        </form>
        </div>
        </center>
        </body>
</html>
 
<?php
if(isset($_POST['cancel']))
{
        header("Location:login.php");
}
if(isset($_POST['submit']))
{
function __autoload($classname)
{
        require_once("$classname.php");
}
$usern=$_POST['username'];
$usere=$_POST['email'];
$userg=$_POST['gender'];
$userd=$_POST['dob'];
$userp=$_POST['password'];
$userc=$_POST['confirm'];
$userno=$_POST['contact'];
$usersq=$_POST['security'];
$usersa=$_POST['ans'];
if(!empty($usern) && !empty($usere) && !empty($userg) && !empty($userd) && !empty($userp) && !empty($userc) && !empty($userno) && !empty($usersq) && !empty($usersa))
{
$user1=new prac($usern,$usere,$userg,$userd,$userp,$userc,$userno);
$date1=$user1->calculate_age();
$bool1=$user1->validate_details($date1);
if($bool1)
{
        $one=mysqli_query($con,"select count(*) from user where email='$usere'");
        $two=mysqli_query($con,"select count(*) from user where mobile='$userno'");
        $one1=mysqli_fetch_row($one);
        $two1=mysqli_fetch_row($two);
        if($one1[0]==0)
        {
                if($two1[0]==0)
                {
                        mysqli_query($con,"Insert into user values('$usern','$u
                        echo "<center>Account Created<center>";
                        echo "<center>Do you want to login?<form action='login.
                }else{echo "<script>alert('Contact Already exists!!')</script>"
        }else{echo "<script>alert('User Already exists!!')</script>";}
}
else
{
        echo '<script>alert("Account Cannot be created!! Provide correct Inform
}
}
else
{
echo "<script>alert('Fill all the fields!!!')</script>";
}
}
?>
