<html>
<head>
<style>
 
input[type=submit] {
  width: 20%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
input[type=text], select {
  width: 150%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid red;
  border-radius: 4px;
  box-sizing: border-box;
}
input[type=password], select {
    width: 150%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid red;
    border-radius: 4px;
    box-sizing: border-box;
  }
 
body {
height:100%;margin:0%;
 
}
.bg
{
background-image:url('solo-travel.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
 
</style>
</head><div class="bg">
  <center>
  <body>
        <br><br><br>
  <div >
  <form name="login" method="post">
   <h1>Welcome to TripTip!!</h1><h3>LOGIN HERE:</h3>
  <table>
  <tr><td><b>Enter email:</b></td><td><input size="20" type="text" name="email" placeholder="Email Address"/></td></tr>
  <tr><td><b>Enter password:</b></td><td><input size="20" type="password" name="pwd" placeholder="Password"/></td></tr></table>
  <input type="submit" name="submit1" value="Sign In"><br>
  <input type="submit" name="fpwd" value="Forgot Password?"><br>
  <a href="hsignup.php">New User!Sign Up Here...</a>
  </form></div>
  </body>
  </center></div>
</html>
<?php
if (isset($_POST['submit1']))
{
session_start();
#$_SESSION['email']=$_POST['email'];
  if(empty($_POST['email']) || empty($_POST['pwd']))
  {
         echo "<script>alert('Enter both the values!!')</script>";
  }
  else
  {
          $uemail=$_POST['email'];
          $upass=$_POST['pwd'];
          $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
          $ua=mysqli_query($con,"select count(*) from admin where email='$uemail'");
          $pa=mysqli_query($con,"select password from admin where email='$uemail'");
          $uc=mysqli_query($con,"select count(*) from user where email='$uemail'");
          $pc=mysqli_query($con,"select password from user where email='$uemail'");
          $res=mysqli_query($con,"select status from user where email='$uemail'");
          $u1=mysqli_fetch_row($ua);
          $p1=mysqli_fetch_row($pa);
          $u2=mysqli_fetch_row($uc);
          $p2=mysqli_fetch_row($pc);
          $res1=mysqli_fetch_row($res);
          if($u1[0]==1 && $u2[0]==0)
          {
                if($p1[0]!=$upass)
                {
                        echo "<script>alert('Password does not match')</script>";
                }
                elseif($p1[0]==$upass)
                {      $_SESSION['aemail']=$_POST['email'];
                        header('location:adminhomepage.php');
                }
           }
          elseif($u2[0]==1 && $u1[0]==0)
          {
                if($p2[0]!=$upass)
                {
                        echo "<script>alert('Password does not match')</script>";
                }
                else
                {
                        if($res1[0]=='active')
                        {       $_SESSION['cemail']=$_POST['email'];
                                 header('location:customerhomepage.php');
                        }
                        else
                        {
                                echo "<script>alert('status inactive,contact admin')</script>";
                        }
                }
          }
 
          elseif($u1[0]==0 && $u2[0]==0)
          {
                echo "<script>alert('Admin or User does not exist')</script>";
          }
 
  }
}
if (isset($_POST['fpwd']))
{
  header('location:fpass.php');
}
?>
