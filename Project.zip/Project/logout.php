<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
 
}
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }
#content
{
        height:100%;
        width:100%;
        background-image:url('Capture.PNG');
        background-size:cover;
        background-repeat:no-repeat;
        background-position:center;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['aemail']))
{
echo "<body id='content'>";
$user1=$_SESSION['aemail'];
        echo "<br><br><br><br><center><h2>Are you sure?</h2><form method='post'><input type='submit' name='submit1' value='Logout'>
                        <input type='submit' name='cancel' value='Cancel'></form></center>";
        if(isset($_POST['submit1']))
        {
                echo "<center><h1>You are being directed to the Login Page</h1></center>";
                session_destroy();
                echo "<script>alert('Session Expired!')</script>";
                header("refresh:1,url=login.php");
        }
        if(isset($_POST['cancel']))
        {
                $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
                $res=mysqli_query($con,"select count(*) from admin where email='$user1'");
                $result=mysqli_fetch_row($res);
                if($result[0]==0)
                {
                        header("refresh:0,url=customerhomepage.php");
                }
                else
                {
                        header("refresh:0,url=adminhomepage.php");
                }
        }
}
elseif(isset($_SESSION['cemail']))
{
echo "<body id='content'>";
$user1=$_SESSION['cemail'];
        echo "<br><br><br><br><center><h2>Are you sure?</h2><form method='post'><input type='submit' name='submit1' value='Logout'>
                        <input type='submit' name='cancel' value='Cancel'></form></center>";
        if(isset($_POST['submit1']))
        {
                echo "<center><h1>You are being directed to the Login Page</h1></center>";
                session_destroy();
                echo "<script>alert('Session Expired!')</script>";
                header("refresh:1,url=login.php");
        }
        if(isset($_POST['cancel']))
        {
                $con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
                $res=mysqli_query($con,"select count(*) from admin where email='$user1'");
                $result=mysqli_fetch_row($res);
                if($result[0]==0)
                {
                        header("refresh:0,url=customerhomepage.php");
                }
                else
                {
                        header("refresh:0,url=adminhomepage.php");
                }
        }
}
 
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
?>
