<?php
        date_default_timezone_set("Asia/Calcutta");
        class prac
        {
                public $username;
                public $email;
                public $gender;
                public $dob;
                private $password;
                private $confirm;
                public $contact;
                function __CONSTRUCT($u,$e,$g,$d,$p,$c,$no)
                {
                        $this->username=$u;
                        $this->email=$e;
                        $this->gender=$g;
                        $this->dob=$d;
                        $this->password=$p;
                        $this->confirm=$c;
                        $this->contact=$no;
                }
                function calculate_age()
                {
                        $dob=$this->dob;
                        $diff=date('Y')-date('Y',strtotime($dob));
                        return $diff;
                }
 
                function validate_details($date1)
                {
                        if(preg_match("/^[A-Za-z]+(\s[A-Za-z]+){0,2}$/",$this->username))
                        {
                                if(preg_match("/^[A-Za-z]+([._][A-Za-z0-9]+)*[0-9]*[@][a-zA-Z]+[.][a-zA-z]{3,5}$/",$this->email))
                                {
                                        if($this->gender == 'Male'||$this->gender == 'Female'||$this->gender == 'Others')
                                        {
                                                if(preg_match("/^[0-9]{2}-[0-9]{2}-[0-9]{4}$/",$this->dob))
                                                {
                                                        if($date1>18)
                                                        {
                                                                if(preg_match("/^[A-Za-z0-9!$*-]+$/",$this->password))
                                                                {
                                                                        if(preg_match("/[A-Z]/",$this->password))
                                                                                {
                                                                                if(preg_match("/[a-z]/",$this->password))
                                                                                {
                                                                                        if(preg_match("/[!*$-]/",$this->password))
                                                                                        {
                                                                                                if($this->password==$this->confirm)
                                                                                                {
                                                                                                        if(preg_match("/^[6-9][0-9]{9}$/",$this->contact))
                                                                                                        {
                                                                                                                return true;
                                                                                                        }else{echo '<script>alert("Invalid Contact")</script>'; return false;}
                                                                                                }else{echo '<script>alert("Passwords do not match")</script>'; return false;}
                                                                                        }else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                                                                }else{echo '<script>alert("Password should contain atleast 1 uppercase, 1 lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                                                        }else{echo '<script>alert("Password should contain atleast 1 uppercase, 1lowercase and !*$- one of these symbols!!!!")</script>'; return false;}
                                                                }else{echo '<script>alert("Invalid Password")</script>'; return false;}
                                                        }else{echo '<script>alert("Invalid Age")</script>'; return false;}
                                                }else{echo '<script>alert("Invalid Date of birth")</script>'; return false;}
                                        }else{echo '<script>alert("Invalid Gender")</script>'; return false;}
                                }else{echo '<script>alert("Invalid Email Address")</script>'; return false;}
                        }else{echo '<script>alert("Invalid Name")</script>'; return false;}
                }
}
 
?>
