<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
 
echo "<body id='content'><center><br><h3>Search Destination:</h3>";
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$result=mysqli_query($con,"select city  from destination");
echo "<br><form method='POST'>
        <b>Select City :</b><select  name='city' >
        <option value=-1>--SELECT--</option>";
                while ($row=mysqli_fetch_row($result))
                {
                        echo "<option value='$row[0]'>$row[0]</option>";
                }
        echo " </select>
        <input type='submit' name='submit' value='Search'>
</form></html>";
 
if(isset($_POST['submit']))
{
        $city=$_POST['city'];
        if($city!=-1)
        {
                //session_start();
                $_SESSION['city']=$city;
                header('location:search_destination_results.php');
        }
        else
        {
                echo "<script>alert('Select a City to search!!')</script>";
        }
}
echo "</center></body>";
 
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
?>
