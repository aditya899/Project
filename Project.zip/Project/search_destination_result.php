<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 20%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
echo "<body id='content'><br><center><h3>Search Destination:</h3><br>";
//session_start();
$city=$_SESSION['city'];
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$result=mysqli_query($con,"select * from destination where city='$city'");
$row=mysqli_fetch_row($result);
$a=array();
$res1=mysqli_query($con,"select review from review_city where city='$city'");
$a=explode(',',$row[2]);
        echo "<html><form method='POST'><table  cellpadding=10>
        <tr><td>City:</td><td>$row[0]</td></tr>
        <tr><td>Description:</td><td>$row[1]</td></tr>
        <tr><td>Hotplaces:</td><td>";
        foreach($a as $b)
        {
        echo "<ul>
                <li>$b</li></ul>";
        }echo "</td></tr>
        <tr><td>Rating:</td><td>$row[3]</td></tr><tr><td>Review:</td><td>";
        while($result1=mysqli_fetch_row($res1))
        {
        echo "<ul>
                <li>$result1[0]</li></ul>";
        }
        echo "</td></tr></table><input type='submit' name='book' value='Book'>";
echo "</form></html>";
 
if(isset($_POST['book']))
{
        header('location:search_hotels.php');
}
echo "</center>";
 
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
?>
