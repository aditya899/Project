<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
echo "<style>input[type=text], select {
  width: 30%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;u
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
 
input[type=submit] {
  width: 10%;
  background-color: Slateblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
 
  }</style>";
echo "<body id='content'><center><br><h3>Book Hotel:</h3><br>";
#session_start();
$city=$_SESSION['city'];
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
echo "<h3>".$_SESSION['city']."</h3>";
$re=mysqli_query($con,"select count(*) from hotels where city='$city'");
$rw=mysqli_fetch_row($re);
if($rw[0]==0)
{
        echo "No hotels are available for the selected city!!";
}
else
{
 
$result=mysqli_query($con,"select * from hotels where city='$city'");
echo "<table cellpadding=15><form method='POST'>
<tr><th>Hotel Name</th><th>Address</th><th>Rating</th><th>Review</th><th>Book</th></tr>";
while($row=mysqli_fetch_row($result))
{
        $res1=mysqli_query($con,"select review from review_hotel where city='$city' and hotel='$row[0]'");
        $a=array();
        while($row1=mysqli_fetch_row($res1))
        {
                        array_push($a,$row1[0]);
        }
        echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td>
        <td>";
        foreach($a as $b)
        {
        echo "<ul><li>$b</li></ul>";
        }
        echo "</td>
        <td><input type='radio' name='book' value='$row[0]'></td></tr>";
}
echo "</table><input type='submit' name='submit' value='Book'>";
echo "</html>";
 
if(isset($_POST['submit']))
{
        if(!empty($_POST['book']))
        {
                $_SESSION['hotel']=$_POST['book'];
                header('location:book_hotel.php');
        }
        else
        {
                echo "<script>alert('Select a hotel!!')</script>";
        }
}
 
}
echo "</center>";
}
 
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
 
?>
