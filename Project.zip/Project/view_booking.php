<html>
<head>
<style>
.bg
{
margin:10px;
background-image:url('./quote1.jpg');
height:100%;background-position:center;background-repeat:no-repeat;background-size:cover;
}
 
  tr:hover {background-color:#e6f5ff;}
</style>
</head>
</html>
<?php
session_start();
if(isset($_SESSION['cemail']))
{
include('customertemplate.php');
 
 
echo "<body id='content'><center><br><br>";
 
//remove and type your code here
#session_start();
$email=$_SESSION['cemail'];
date_default_timezone_set("Asia/Calcutta");
$con=mysqli_connect("localhost","T1014669","#infy123","test_T1014669");
$res1=mysqli_query($con,"select count(*) from bookings where useremail='$email'");
$eres=mysqli_fetch_row($res1);
if($eres[0]!=0)
{
        $res2=mysqli_query($con,"select bid,city,hotel_name,no_of_rooms,check_in,check_out,total_price from bookings where useremail='$email'");
        echo "<h3>Your Bookings are:</h3><center><table border=2  bgcolor=#b3e0ff>
        <tr><th>Booking Id</th><th>City</th><th>Hotel</th><th>No. of Rooms</th><th>Check In</th><th>Check Out</th><th>No. of Days</th><th>Price</th></tr> ";
        while($view=mysqli_fetch_row($res2))
        {
               $ci=date('d-m-Y',strtotime($view[4]));
                $co=date('d-m-Y',strtotime($view[5]));
                $diff1=$co-$ci;
                echo "<tr><td>".$view[0]."</td><td>".$view[1]."</td><td>".$view[2]."</td><td>".$view[3]."</td><td>".$view[4]."</td><td>".$view[5]."</td><td>".$diff1."</td><td>".$view[6]."</td></tr>";
        }
        echo "</table></center>";
}
else
{
        echo "<center><h1>You don't have any booking!!</h1><br>
                <h3>Redirecting you to the Home...</h3></center>";
        header("refresh:1,url=customerhomepage.php");
}
echo "</center></html>";
}
else
{
        echo "<center><h1 class='bg'>Page not available,login first!!</h1></center>";
        header("refresh:3,url=login.php");
}
 
 
?>
